#include"Header.h"
void Test16() {
	string filename { "Task16.txt" };
	ofstream fout(filename.c_str());
	if (!fout) { 
		cerr << "Could not open " << filename << endl;
		exit(EXIT_FAILURE);
	}
	else {
		fout << "In that case, the program enters the loop, displays the character, increments the count, and reads the next character.";
		fout.close();
	}

	string str;
	ifstream fin(filename.c_str());
	if (!fin) {
		cerr << "Could not open " << filename << endl;
		exit(EXIT_FAILURE);
	}
	else {
		char ch;
		while (fin.get(ch)) str += ch;
		fin.close();
	}

	string str_first = str;
	int pos = 0;
	int n = 0;
	bool flag = 0;
	for (auto x : str_first) {
		if(x >= 65 and flag == 0) ++n;
		if (x < 65) ++flag;
	}	
	str_first.replace(pos, n, "NEW");
	fout.open(filename.c_str(), ios_base::out | ios_base::app);
	if (!fout) { 
		cerr << "Could not open " << filename << endl;
		exit(EXIT_FAILURE);
	}
	else {
		fout << endl << str_first;
	    fout.close();
	}

	string str_third = str;
	int SP_count = 0;
	pos = 0;
	n = 0;
	flag = 0;
	int i = 0;
	for (auto x : str_third) {
		if (x == 32) ++SP_count;
		if (SP_count == 2 and flag == 0) { 
			pos = i + 1;
			++flag;
		}
		if (SP_count == 2 and x >= 65) ++n;
		++i;
	}
	str_third.replace(pos, n, "NEW");
	fout.open(filename.c_str(), ios_base::out | ios_base::app);
	if (!fout) {
		cerr << "Could not open " << filename << endl;
		exit(EXIT_FAILURE);
	}
	else {
		fout << endl << str_third;
		fout.close();
	}

	int ALL_spaces = 0;
	for (auto x : str) {
		if (x == 32) ++ALL_spaces;
	}
	cout << "Enter the word number to substitute from 1 to " << ALL_spaces + 1 << ": ";
	int s_word;
	cin >> s_word;
	--s_word;

	string str_s = str;
	SP_count = 0;
	pos = 0;
	n = 0;
	flag = 0;
	i = 0;
	for (auto x : str_s) {
		if (x == 32) ++SP_count;
		if (SP_count == s_word and flag == 0) {
			pos = i + 1;
			++flag;
		}
		if (SP_count == s_word and x >= 65) ++n;
		++i;
	}
	str_s.replace(pos, n, "NEW");
	fout.open(filename.c_str(), ios_base::out | ios_base::app);
	if (!fout) {
		cerr << "Could not open " << filename << endl;
		exit(EXIT_FAILURE);
	}
	else {
		fout << endl << str_s;
		fout.close();
	}

	string str_last = str;
	SP_count = 0;
	pos = 0;
	n = 0;
	flag = 0;
	i = 0;
	for (auto x : str_last) {
		if (x == 32) ++SP_count;
		if (SP_count == ALL_spaces and flag == 0) {
			pos = i + 1;
			++flag;
		}
		if (SP_count == ALL_spaces && x >= 65) ++n;
		++i;
	}
	str_last.replace(pos, n, "NEW");
	fout.open(filename.c_str(), ios_base::out | ios_base::app);
	if (!fout) {
		cerr << "Could not open " << filename << endl;
		exit(EXIT_FAILURE);
	}
	else {
		fout << endl << str_last;
	}
}

void Test17_txt() {
	vector<int> value;
	int i;
	for (i = 0; i < 10; ++i)
		value.push_back(rand() % 10000);

	string filename_a{ "Task17a.txt" };
	ofstream fout(filename_a.c_str());
	if (!fout) {
		cerr << "Could not open " << filename_a << endl;
		exit(1);
	}
	else {
		for (auto x : value) {
			cout << x << " ";
			fout << x << " ";
		}
		cout << endl;
		fout.close();
	}

	ifstream fin(filename_a.c_str());
	if (!fin) {
		cerr << "Could not open " << filename_a << endl;
		exit(EXIT_FAILURE);
	}
	else {
		string filename_b{ "Task17b.txt" };
		ofstream fout(filename_b.c_str());
		if (!fout) {
			cerr << "Could not open " << filename_b << endl;
			exit(EXIT_FAILURE);
		}
		else {
			vector<int> arr_of_individual_numbers;
			char ch;
			while (fin.get(ch)) {
				int number;
				switch (ch) {
				case 48:
					number = 0;
					break;
				case 49:
					number = 1;
					break;
				case 50:
					number = 2;
					break;
				case 51:
					number = 3;
					break;
				case 52:
					number = 4;
					break;
				case 53:
					number = 5;
					break;
				case 54:
					number = 6;
					break;
				case 55:
					number = 7;
					break;
				case 56:
					number = 8;
					break;
				case 57:
					number = 9;
					break;
				default:
					number = -1;
						break;
				}
				arr_of_individual_numbers.push_back(number);
			}

			vector<int> temperary;
			int whole_number = 0;
			int number_register = 1;
			for(auto x : arr_of_individual_numbers){
				if (x != -1) {
					whole_number = x + whole_number * number_register;
					number_register = 10;
				}
				else {
					if(whole_number % 2 == 0) temperary.push_back(whole_number);
					whole_number = 0;
					number_register = 1;
				}
			}
			
			cout << endl;
			for (auto x : temperary) {
				fout << x << " ";
				cout << x << " ";
			}
			cout << endl;
		}
	}
}

void Test17_data() {
	vector<int> value;
	int value_for_reinterpret_cast = 0;
	int i;
	for (i = 0; i < 10; ++i)
		value.push_back(rand() % 10000);

	string filename_a{ "Task17a.data" };
	ofstream fout(filename_a.c_str(), ios_base::binary);
	if (!fout) {
		cerr << "Could not open " << filename_a << endl;
		exit(EXIT_FAILURE);
	}
	else {
		for (int x : value) {
			cout << x << " ";
			fout.write(reinterpret_cast<const char*>(&x), sizeof(x));
		}
		cout << endl;
		fout.close();
	}

	string filename_b{ "Tast17b.data" };
	fout.open(filename_b.c_str(), ios_base::binary);
	ifstream fin;
	int temp_value = 0;
	if (!fout) {
		cerr << "Could not open " << filename_b << endl;
		exit(EXIT_FAILURE);
	}
	else {
		fin.open(filename_a.c_str(), ios_base::binary);
		if (!fin) {
			cerr << "Could not open " << filename_a << endl;
			exit(EXIT_FAILURE);
		}
		else {
			fin.read(reinterpret_cast<char*>(&temp_value), sizeof(temp_value));

			while (fin and !fin.eof()) {
				if (temp_value % 2 == 0) {
					fout.write(reinterpret_cast<const char*>(&temp_value), sizeof(temp_value));
				}
				fin.read(reinterpret_cast<char*>(&temp_value), sizeof(temp_value));
			}
			fin.close();
		}
	}
	fout.close();

	fin.open(filename_b.c_str(), ios_base::binary);
	if (!fin) {
		cerr << "Could not open " << filename_b << endl;
		exit(EXIT_FAILURE);
	}
	else {
		fin.read(reinterpret_cast<char*>(&temp_value), sizeof(temp_value));
		while (fin and !fin.eof()) {
			cout << temp_value << " ";
			fin.read(reinterpret_cast<char*>(&temp_value), sizeof(temp_value));
		}
	}
}

void Test18() {
	string fill{ "File, 555, Edit, 74, View, 91." };
	string filename_a{ "Task18_a.txt" };
	ofstream fout(filename_a.c_str());
	if (!fout) {
		cerr << "Could not open " << filename_a << endl;
		exit(EXIT_FAILURE);
	}
	else {
		for (auto x : fill) {
			fout << x;
			cout << x;
		}
	}
	cout << endl;
	fout.close();

	string filename_b{ "Task18_b.txt" };
	string filename_c{ "Task18_c.txt" };
	ifstream fin(filename_a.c_str());
	ifstream fin_b(filename_b.c_str());
	ifstream fin_c(filename_c.c_str());
	ofstream fout_b(filename_b.c_str());
	ofstream fout_c(filename_c.c_str());
	if (!fin and fin.eof()) {
		cerr << "Could not open " << filename_a << endl;
		exit(EXIT_FAILURE);
	}
	else if ((!fin_b and fin_b.eof()) and !fout_b) {
		cerr << "Could not open " << filename_b << endl;
		exit(EXIT_FAILURE);
	}
	else if ((!fin_c and fin_c.eof()) and !fout_c) {
		cerr << "Could not open " << filename_c << endl;
		exit(EXIT_FAILURE);
	}
	else {
		char ch;
		while (fin.get(ch)) {
			if (ch > 47 and ch < 58) fout_b.put(ch);
			else if (ch != 32) fout_c.put(ch);
		}
		fout_b.close();
		fout_c.close();
		while (fin_b.get(ch)) {
			cout << ch;
		}
		cout << endl;
		while (fin_c.get(ch)) {
			cout << ch;
		}
		cout << endl;
	}
}

void Test19() {
	string filename{ "Task19.txt" };
	ofstream fout(filename.c_str());
	if (!fout) {
		cerr << "Could not open " << filename << " to write." << endl;
		exit(EXIT_FAILURE);
	}
	else {
		int count = 0;
		string str{};
		while (count < 6 and fout and !fout.eof()) {
			cout << "Enter the string number " << count + 1 << ": " << endl;
			getline(cin, str);
			fout << str;
			fout << endl;
			++count;
		}
	}
	fout.close();

	ifstream fin(filename.c_str());
	if (!fin) {
		cerr << "Could not open " << filename << " to read." << endl;
		exit(EXIT_FAILURE);
	}
	else {
		char ch = ' ';
		cout << endl;
		while (fin and !fin.eof()) {
			fin.get(ch);
			cout << ch;
		}
	}
}