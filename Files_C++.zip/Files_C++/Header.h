#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include<ctime>
#include<vector>
#include<algorithm>
#include<iterator>
using namespace std;

void Test16();
void Test17_txt();
void Test17_data();
void Test18();
void Test19();