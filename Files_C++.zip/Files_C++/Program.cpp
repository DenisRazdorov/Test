#include"Header.h"
int main() {
	srand(time(NULL));
	/*Test16();*/
	/*Test17_txt();*/
	/*Test17_data();*/
	/*Test18();*/
	Test19();
	return 0;
}